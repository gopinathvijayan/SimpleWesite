<?php

$hostname = 'localhost';
$username = 'root';
$password = '';
$databasename = 'nv_aeh';

$mysqli =mysqli_connect($hostname, $username, $password, $databasename);

?>