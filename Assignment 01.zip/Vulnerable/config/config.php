<?php

$hostname = 'localhost';
$username = 'root';
$password = '';
$databasename = 'aeh';

$mysqli =mysqli_connect($hostname, $username, $password, $databasename);

?>